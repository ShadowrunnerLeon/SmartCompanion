#pragma once

#ifdef SPEECHRECOGNITIONMODULE_EXPORTS
#define SPEECHRECOGNITIONMODULE_API __declspec(dllexport)
#else
#define SPEECHRECOGNITIONMODULE_API __declspec(dllimport)
#endif

#include "E:/SmartCompanion/ThirdParty/PortAudio/Include/portaudio.h"
#include "E:/SmartCompanion/ThirdParty/Vosk/vosk-win64/vosk_api.h"

#include <string>

#include <windows.h>
#define WIN32_LEAN_AND_MEAN

static VoskModel* model;
static VoskRecognizer* recognizer;
static PaStream* stream;
static PaStreamParameters inputParametrs;

static const size_t SPEECH_BUFFER_SIZE = 4096;
static const std::string BaseDir = "E:/SmartCompanion";
static char data[SPEECH_BUFFER_SIZE];
static std::string recognizedText;

extern "C" SPEECHRECOGNITIONMODULE_API const char* Initialize();
extern "C" SPEECHRECOGNITIONMODULE_API const char* Run();
extern "C" SPEECHRECOGNITIONMODULE_API void Shutdown();

bool InializeModelAndRecognizer();
bool InitializePortAudio();
bool SetAudioDevice();
bool OpenStream();
bool StartStream();

bool ReadDataFromStream();
std::string Recognize();