#include "SpeechRecognitionModule.h"
#include "simpleson/json.h"

#include <iostream>

const char* Initialize()
{
	if (!InializeModelAndRecognizer() ||
		!InitializePortAudio() ||
		!SetAudioDevice() ||
		!OpenStream() ||
		!StartStream())
	{
		return "SpeechRecognitonModule: Initialize failed";
	}
	return "SpeechRecognitonModule: Intialize successed";
}

const char* Run()
{
	bool isCorrectRead = ReadDataFromStream();
	if (!isCorrectRead) return {};

	recognizedText = Recognize();
	return recognizedText.c_str();
}

void Shutdown()
{
	Pa_CloseStream(stream);
	vosk_recognizer_free(recognizer);
	vosk_model_free(model);
}

bool InializeModelAndRecognizer()
{
	std::string path = BaseDir + "\\Models\\Vosk\\vosk-model-small-en-us-0.15";

	model = vosk_model_new(path.c_str());
	if (!model) 
	{
		std::cerr << "InializeModelAndRecognizer: vosk_model_new failed" << std::endl;
		return false;
	}

	recognizer = vosk_recognizer_new(model, 16000.0);
	if (!recognizer)
	{
		std::cerr << "InializeModelAndRecognizer: vosk_recognizer_new failed" << std::endl;
		return false;
	}

	return true;
}

bool InitializePortAudio()
{
	PaError err = Pa_Initialize();
	if (err != paNoError)
	{
		std::cerr << "InitializePortAudio: Pa_Initialize: " << Pa_GetErrorText(err) << std::endl;
		return false;
	}

	return true;
}

bool SetAudioDevice()
{
	inputParametrs.channelCount = 1;
	inputParametrs.sampleFormat = paInt16;
	inputParametrs.hostApiSpecificStreamInfo = nullptr;
	inputParametrs.device = Pa_GetDefaultInputDevice();

	if (inputParametrs.device == paNoDevice)
	{
		std::cerr << "SetAudioDevice: Pa_GetDefaultInputDevice: no device" << std::endl;
		return false;
	}

	return true;
}

bool OpenStream()
{
	PaError err = Pa_OpenStream(&stream, &inputParametrs, nullptr, 16000.0, 8192, 0, nullptr, nullptr);
	if (err != paNoError)
	{
		std::cerr << "OpenStream: Pa_OpenStream: " << Pa_GetErrorText(err) << std::endl;
		return false;
	}

	return true;
}

bool StartStream()
{
	PaError err = Pa_StartStream(stream);
	if (err != paNoError)
	{
		std::cerr << "StartStream: Pa_StartStream: " << Pa_GetErrorText(err);
		return false;
	}

	return true;
}

bool ReadDataFromStream()
{
	PaError err = Pa_ReadStream(stream, (void*)data, SPEECH_BUFFER_SIZE / 2);
	if (err != paNoError && err != paInputOverflowed)
	{
		std::cerr << "ReadDataFromStream: Pa_ReadStream: " << Pa_GetErrorText(err) << std::endl;
		return false;
	}

	return true;
}

std::string Recognize()
{
	if (vosk_recognizer_accept_waveform(recognizer, data, sizeof(data)) == -1)
	{
		std::cerr << "Recognize: vosk_recognizer_accept_waveform: error" << std::endl;
		return {};
	}

	auto resRecognition(vosk_recognizer_result(recognizer));
	return json::jobject::parse(resRecognition).get("text");
}
